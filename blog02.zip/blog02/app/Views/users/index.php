<ul>
    <?php foreach ($usuarios as $usuario) : ?>
    <li><?= $usuario['username']; ?></li>
    <?php endforeach; ?>
</ul>